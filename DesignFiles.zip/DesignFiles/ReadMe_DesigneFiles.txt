This folder contains the solidworks (sldprt) files for the 3-d printed Langmuir trough. The 3d view and how the parts should be assembled are presented in �Interfacial microrheology and tensiometry in a miniature, 3-d printed Langmuir trough� published in Journal of Colloid and Interface Science. 
Part 5 is custom designed for the inverted Leica DM microscope. The design simply can be modified to fit to other microscopes. Par1 has two version: one for performing experiment with two fluids (e.g. oil-water interface), and one for single fluid (e.g. air-water interface). 

Number of parts needed for each apparatus:
Part1: 1
Part2: 2
Part3: 2
Part4: 2
Part 5: 1
Holder: 4

